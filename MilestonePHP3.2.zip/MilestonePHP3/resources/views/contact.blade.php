@extends('layouts/layout')

@section('content')
	<h1>Contact Information</h1>
@endsection

