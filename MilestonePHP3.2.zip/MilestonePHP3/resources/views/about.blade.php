@extends('layouts/layout')
@section('content')
	<h1>Team: Vien, Alex, Anh </h1>
@endsection
