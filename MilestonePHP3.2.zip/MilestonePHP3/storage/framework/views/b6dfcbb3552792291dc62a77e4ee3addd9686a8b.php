<?php $__env->startSection('content'); ?>
	<h1>Final Project</h1>
	<h4>Vien, Alex, Anh</h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexv\Documents\1.LaravelWorkspace\MilestonePHP3\resources\views/home.blade.php ENDPATH**/ ?>